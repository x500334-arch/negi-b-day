🎵 PUT YOUR SONG HERE
=====================

Required filename (or change birthdayData.music in js/app.js):

  birthday-song.mp3

Notes
- Music never autoplays; the visitor taps the floating ♪ button.
- If the file is missing the site still works and shows a friendly hint.
- MP3 is the most compatible format. Keep it under ~5 MB if possible.
