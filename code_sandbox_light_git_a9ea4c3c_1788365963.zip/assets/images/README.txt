📸 PUT YOUR PHOTOS HERE
========================

Required filenames (or change the paths in js/app.js → birthdayData):

  hero.jpg       → main photo of the birthday girl (square crop looks best, ~800×800)
  memory1.jpg    → gallery polaroid 1
  memory2.jpg    → gallery polaroid 2
  memory3.jpg    → gallery polaroid 3
  memory4.jpg    → gallery polaroid 4

Tips
- Keep each image under ~400 KB for fast loading (JPG or WebP).
- Square or near-square photos fit the polaroid frames best.
- Until you add a photo, the site shows a tasteful placeholder automatically.
- To add more memories, append entries to birthdayData.memories in js/app.js.
